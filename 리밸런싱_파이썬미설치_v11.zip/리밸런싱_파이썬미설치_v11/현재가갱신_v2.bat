@echo off
chcp 65001 >nul
title Update prices
echo Fetching current prices... please wait.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update_prices_v2.ps1"
if errorlevel 1 (
  echo.
  echo Something went wrong. Please close this window and try again.
  pause
)
