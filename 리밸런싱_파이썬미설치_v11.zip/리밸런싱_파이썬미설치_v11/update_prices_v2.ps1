﻿# update_prices_v2.ps1 - fetch current prices (Naver, then Naver polling, then Yahoo) and save prices_v1.js
# Works with the PowerShell built into Windows 10/11. No installation needed.
$ErrorActionPreference = 'Continue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$dir = $PSScriptRoot
if (-not $dir) { $dir = Split-Path -Parent $MyInvocation.MyCommand.Path }
$listFile = Join-Path $dir 'tickers_v1.txt'

# 1) tickers
if (-not (Test-Path -LiteralPath $listFile)) {
    $defaultText = "# 현재가를 가져올 종목코드(6자리)를 적으세요. 공백이나 줄바꿈으로 구분합니다.`r`n278530 379800 357870 305080 411060`r`n"
    [System.IO.File]::WriteAllText($listFile, $defaultText, (New-Object System.Text.UTF8Encoding($true)))
    Write-Host "Created tickers_v1.txt with default tickers. Edit it in Notepad to change tickers."
}
$raw = Get-Content -LiteralPath $listFile -Raw -Encoding UTF8
$lines = $raw -split "`r?`n" | ForEach-Object { ($_ -split '#')[0] }
$codes = @(($lines -join ' ') -split '[\s,;]+' | Where-Object { $_ -match '^[0-9A-Za-z]{6}$' } | ForEach-Object { $_.ToUpper() } | Select-Object -Unique)
if ($codes.Count -eq 0) { Write-Host "No valid tickers found in tickers_v1.txt (6-character codes)."; Read-Host "Press Enter to close"; exit 1 }

# 2) fetch (3 sources, tried in order: naver mobile -> naver polling -> yahoo)
function Get-Utf8Json($uri) {
    $resp = Invoke-WebRequest -Uri $uri -UseBasicParsing -UserAgent 'Mozilla/5.0' -TimeoutSec 10
    return ([System.Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray()) | ConvertFrom-Json)
}
function To-Price($v) { try { return [double](([string]$v) -replace ',', '') } catch { return 0 } }

function Get-NaverMobile($c) {
    $r = Get-Utf8Json ("https://m.stock.naver.com/api/stock/{0}/basic" -f $c)
    return @{ price = (To-Price $r.closePrice); name = [string]$r.stockName; src = 'naver' }
}
function Get-NaverPolling($c) {
    $resp = Invoke-WebRequest -Uri ("https://polling.finance.naver.com/api/realtime?query=SERVICE_ITEM:{0}" -f $c) -UseBasicParsing -UserAgent 'Mozilla/5.0' -TimeoutSec 10
    $bytes = $resp.RawContentStream.ToArray()
    $enc = [System.Text.Encoding]::GetEncoding(51949)   # euc-kr
    $txt = $enc.GetString($bytes)
    $j = $txt | ConvertFrom-Json
    $it = $j.result.areas[0].datas[0]
    return @{ price = (To-Price $it.nv); name = [string]$it.nm; src = 'naver2' }
}
function Get-Yahoo($c) {
    $r = Get-Utf8Json ("https://query1.finance.yahoo.com/v8/finance/chart/{0}.KS?range=5d&interval=1d" -f $c)
    $m = $r.chart.result[0].meta
    return @{ price = (To-Price $m.regularMarketPrice); name = ''; src = 'yahoo' }
}

Write-Host "Fetching prices for $($codes.Count) ticker(s)..."
$items = [ordered]@{}
$fail = @()
foreach ($c in $codes) {
    $got = $null
    foreach ($fn in @('Get-NaverMobile','Get-NaverPolling','Get-Yahoo')) {
        try {
            $x = & $fn $c
            if ($x -and $x.price -gt 0) { $got = $x; break }
        } catch { }
    }
    if ($got) {
        $items[$c] = [ordered]@{
            price = $got.price
            name  = $got.name
            at    = (Get-Date).ToString("yyyy-MM-dd'T'HH:mm:sszzz")
            src   = $got.src
        }
        Write-Host ("  {0}  {1}  {2:N0}  [{3}]" -f $c, $got.name, $got.price, $got.src)
    } else {
        $fail += $c
        Write-Host "  $c  failed (all sources)"
    }
}

# 3) save prices_v1.js (read by the HTML tool in the same folder)
$srcs = @($items.Values | ForEach-Object { $_.src } | Select-Object -Unique) -join '+'
$obj = [ordered]@{ asof = (Get-Date).ToString('yyyy-MM-dd HH:mm'); source = $srcs; items = $items }
$json = $obj | ConvertTo-Json -Depth 6 -Compress
$outFile = Join-Path $dir 'prices_v1.js'
[System.IO.File]::WriteAllText($outFile, ("window.PRICES = " + $json + ";`n"), (New-Object System.Text.UTF8Encoding($false)))
Write-Host "Saved: prices_v1.js"

# 4) open the newest HTML tool in the same folder
$html = Get-ChildItem -LiteralPath $dir -Filter '*.html' |
    Where-Object { $_.Name -match '^리밸런싱툴_v(\d+)\.html$' } |
    Sort-Object { [int]($_.Name -replace '^리밸런싱툴_v(\d+)\.html$', '$1') } -Descending |
    Select-Object -First 1
if ($fail.Count -gt 0) {
    Write-Host ""
    Write-Host ("Could not get prices for: " + ($fail -join ', '))
    Write-Host "Check the ticker codes, or type those prices in the tool by hand."
}
if ($html) {
    Start-Process -FilePath $html.FullName
} else {
    Write-Host "Tool HTML file (리밸런싱툴_v*.html) was not found in this folder."
    Read-Host "Press Enter to close"
    exit 1
}
if ($fail.Count -gt 0) { Read-Host "Press Enter to close" }
exit 0
