@echo off
chcp 65001 >nul
title Update prices
set "HERE=%~dp0"
if exist "%HERE%_done.tmp" del "%HERE%_done.tmp" >nul 2>&1
echo Fetching current prices... please wait.
echo (This can take up to 1-2 minutes. Please do not close this window.)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "& '%HERE%update_prices_v3.ps1'; exit $LASTEXITCODE"
if not exist "%HERE%_done.tmp" (
  echo.
  echo Something went wrong. The price update did not finish.
  echo Please take a screenshot of this window and send it.
  pause
  exit /b 1
)
del "%HERE%_done.tmp" >nul 2>&1
