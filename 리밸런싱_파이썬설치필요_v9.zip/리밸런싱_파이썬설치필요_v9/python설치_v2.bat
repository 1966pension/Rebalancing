@echo off
setlocal
title Python setup for rebalancing tool (v2)
echo ============================================
echo  Python + price libraries installer (v2)
echo ============================================
echo.

echo [1/3] Checking for Python...
set "PY="
python --version >nul 2>nul && set "PY=python"
if not defined PY (
  py --version >nul 2>nul && set "PY=py"
)
if defined PY goto :havepy

echo Python was not found. Installing Python 3.12 for the current user...
winget --version >nul 2>nul
if %errorlevel%==0 (
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
) else (
  echo winget not available. Downloading installer from python.org...
  curl -L -o "%TEMP%\python_setup.exe" "https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe"
  if errorlevel 1 (
    echo Download failed. Check your internet connection, or install Python manually from https://www.python.org/downloads/
    pause
    exit /b 1
  )
  "%TEMP%\python_setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1
)

rem PATH of this window is not refreshed after install, so look in the default location.
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PY (
  echo.
  echo Python was installed but could not be located in this window.
  echo Close this window, then double-click this file once more.
  pause
  exit /b 0
)

:havepy
echo.
echo Using: %PY%
"%PY%" --version

echo.
echo [2/3] Updating pip...
"%PY%" -m pip install --upgrade pip

echo.
echo [3/3] Installing price libraries (finance-datareader, pykrx)...
"%PY%" -m pip install --upgrade finance-datareader pykrx

echo.
"%PY%" -c "import FinanceDataReader, pykrx; print('Libraries OK')"
echo.
echo Done. Python and the price libraries are ready.
echo Next: double-click the .py file (Rebalancing run file) in this folder.
echo If the .py file opens in Notepad, right-click it and choose Open with - Python.
echo.
pause
