#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
리밸런싱_실행_v3.py  -  더블클릭하면 리밸런싱 툴이 브라우저로 열립니다.

 * 같은 폴더의 '리밸런싱툴_v*.html' 중 가장 높은 버전을 엽니다.
 * 화면의 [현재가 불러오기] 단추를 누르면 이 프로그램이 네이버에서 현재가를 조회해 채워 줍니다.
 * 검은 창(콘솔)은 사용하는 동안 열어 두세요. 다 쓰셨으면 창을 닫으면 됩니다.
 * 화면의 [엑셀 다운로드]를 누르면 결과 엑셀이 이 프로그램이 있는 폴더에 저장됩니다.
 * 내 PC(127.0.0.1)에서만 동작하며 밖으로 열리지 않습니다. 로그인·가입은 필요 없습니다.
"""
import sys, os, re, json, datetime, threading, webbrowser, urllib.request, urllib.parse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

HERE = Path(__file__).resolve().parent
UA = {"User-Agent": "Mozilla/5.0"}
PORTS = list(range(8765, 8776))
MAX_UPLOAD = 20 * 1024 * 1024
NAME_OK = re.compile(r'^[0-9A-Za-z가-힣_\-\. ]{1,120}\.xlsx$')


def unique_path(name):
    p = HERE / name
    stem, suf, n = p.stem, p.suffix, 1
    while p.exists():
        p = HERE / ('%s_%d%s' % (stem, n, suf))
        n += 1
    return p


# ---------------- 현재가 조회 (네이버 → FinanceDataReader → pykrx) ----------------
def http_get(url, enc="utf-8"):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=10) as r:
        return r.read().decode(enc, errors="replace")


def to_num(v):
    try:
        return float(str(v).replace(",", "").strip())
    except Exception:
        return 0.0


def parse_naver_polling(text, code):
    j = json.loads(text)
    for area in j.get("result", {}).get("areas", []):
        for d in area.get("datas", []):
            if d.get("cd") == code:
                p = to_num(d.get("nv"))
                if p > 0:
                    return p, d.get("nm") or ""
    return None


def parse_naver_mobile(text, code):
    j = json.loads(text)
    p = to_num(j.get("closePrice"))
    if p > 0:
        return p, j.get("stockName") or ""
    return None


def src_naver(code):
    # 1순위: 선생님 PC에서 실제로 확인된 모바일 주소
    try:
        r = parse_naver_mobile(http_get("https://m.stock.naver.com/api/stock/%s/basic" % code), code)
        if r:
            return r + ("naver",)
    except Exception:
        pass
    try:
        r = parse_naver_polling(
            http_get("https://polling.finance.naver.com/api/realtime?query=SERVICE_ITEM:" + code, "euc-kr"), code)
        if r:
            return r + ("naver",)
    except Exception:
        pass
    return None


_fdr_names = None


def src_fdr(code):
    global _fdr_names
    try:
        import FinanceDataReader as fdr
        df = fdr.DataReader(code)
        p = float(df["Close"].dropna().iloc[-1])
        if _fdr_names is None:
            _fdr_names = {}
            for mk in ("ETF/KR", "KRX"):
                try:
                    lst = fdr.StockListing(mk)
                    sc = "Symbol" if "Symbol" in lst.columns else "Code"
                    _fdr_names.update(dict(zip(lst[sc].astype(str), lst["Name"].astype(str))))
                except Exception:
                    pass
        if p > 0:
            return p, _fdr_names.get(code, ""), "FinanceDataReader"
    except Exception:
        pass
    return None


def src_pykrx(code):
    try:
        from pykrx import stock
        end = datetime.date.today()
        start = end - datetime.timedelta(days=14)
        df = stock.get_etf_ohlcv_by_date(start.strftime("%Y%m%d"), end.strftime("%Y%m%d"), code)
        if df is None or df.empty:
            df = stock.get_market_ohlcv_by_date(start.strftime("%Y%m%d"), end.strftime("%Y%m%d"), code)
        p = float(df["종가"].iloc[-1])
        try:
            nm = stock.get_etf_ticker_name(code) or stock.get_market_ticker_name(code)
        except Exception:
            nm = ""
        if p > 0:
            return p, nm or "", "pykrx"
    except Exception:
        pass
    return None


def fetch_one(code):
    now = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    for fn in (src_naver, src_fdr, src_pykrx):
        try:
            r = fn(code)
        except Exception:
            r = None
        if r:
            price, name, src = r
            return {"price": price, "name": name, "at": now, "src": src}
    return None


def fetch_many(codes):
    with ThreadPoolExecutor(max_workers=5) as ex:
        res = list(ex.map(fetch_one, codes))
    items = {c: r for c, r in zip(codes, res) if r}
    failed = [c for c, r in zip(codes, res) if not r]
    srcs = sorted({v["src"] for v in items.values()})
    return {"asof": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "source": ", ".join(srcs),
            "items": items, "failed": failed}


# ---------------- 웹 서버 ----------------
def find_html():
    best, bv = None, -1
    for p in HERE.glob("리밸런싱툴_v*.html"):
        m = re.search(r"_v(\d+)\.html$", p.name)
        if m and int(m.group(1)) > bv:
            best, bv = p, int(m.group(1))
    return best


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _local_ok(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        if host not in ("127.0.0.1", "localhost"):
            return False
        origin = self.headers.get("Origin")
        if origin is not None:
            m = re.fullmatch(r"http://(127\.0\.0\.1|localhost)(:\d+)?", origin)
            if not m:
                return False
        return True

    def do_POST(self):
        if not self._local_ok():
            return self._send(403, b"forbidden", "text/plain")
        u = urllib.parse.urlparse(self.path)
        if u.path != "/api/save-xlsx":
            return self._send(404, b"not found", "text/plain")
        name = os.path.basename(urllib.parse.parse_qs(u.query).get("name", [""])[0])
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if not NAME_OK.match(name) or n <= 0 or n > MAX_UPLOAD:
            return self._send(400, json.dumps({"ok": False, "error": "bad request"}).encode(), "application/json")
        body = self.rfile.read(n)
        if body[:2] != b"PK":
            return self._send(400, json.dumps({"ok": False, "error": "not xlsx"}).encode(), "application/json")
        try:
            p = unique_path(name)
            p.write_bytes(body)
        except Exception as e:
            return self._send(500, json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
        print(" 엑셀 저장: %s" % p.name)
        return self._send(200, json.dumps({"ok": True, "name": p.name, "folder": str(HERE)}, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def do_GET(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        if host not in ("127.0.0.1", "localhost"):
            return self._send(403, b"forbidden", "text/plain")
        u = urllib.parse.urlparse(self.path)
        if u.path in ("/", "/index.html"):
            f = find_html()
            if not f:
                return self._send(404, "리밸런싱툴_v*.html 파일을 이 프로그램과 같은 폴더에 두세요.".encode("utf-8"), "text/plain; charset=utf-8")
            return self._send(200, f.read_bytes(), "text/html; charset=utf-8")
        if u.path == "/api/prices":
            q = urllib.parse.parse_qs(u.query)
            raw = ",".join(q.get("codes", []))
            codes = []
            for c in raw.split(","):
                c = c.strip().upper()
                if re.fullmatch(r"[0-9A-Z]{6}", c) and c not in codes:
                    codes.append(c)
            codes = codes[:30]
            data = fetch_many(codes) if codes else {"asof": "", "source": "", "items": {}, "failed": []}
            return self._send(200, json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
        if u.path == "/favicon.ico":
            return self._send(204, b"", "image/x-icon")
        return self._send(404, b"not found", "text/plain")


class ExclusiveServer(ThreadingHTTPServer):
    """이미 쓰는 포트는 건너뛰게 한다. (Windows는 기본 설정이면 같은 포트에 겹쳐 열려,
    예전에 켜 둔 창이 새 창 대신 응답하는 문제가 생긴다.)"""
    allow_reuse_address = False
    def server_bind(self):
        if os.name == "nt":
            import socket
            try:
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            except Exception:
                pass
        super().server_bind()


def main():
    f = find_html()
    if not f:
        print("리밸런싱툴_v*.html 파일을 이 프로그램과 같은 폴더에 두세요.")
        input("Enter 키를 누르면 닫힙니다.")
        return 1
    server = None
    for port in PORTS:
        try:
            server = ExclusiveServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            continue
    if not server:
        print("사용할 수 있는 포트가 없습니다. 이미 실행 중인 창이 있으면 닫고 다시 실행하세요.")
        input("Enter 키를 누르면 닫힙니다.")
        return 1
    url = "http://127.0.0.1:%d/" % server.server_address[1]
    print("=" * 52)
    print(" 리밸런싱 툴이 실행 중입니다")
    print(" 열린 파일: %s" % f.name)
    print(" 주소: %s" % url)
    print("")
    print(" * 이 검은 창은 사용하는 동안 열어 두세요.")
    print(" * 다 쓰셨으면 이 창을 닫으면 됩니다.")
    print(" * 엑셀은 이 폴더에 저장됩니다: %s" % HERE)
    print("=" * 52)
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print("오류가 발생했습니다:", e)
        input("Enter 키를 누르면 닫힙니다.")
